README:
Usage: Give the command as follows:
./assignment4 ./assignment4 OneWay2.JPG OneWay3.JPG OneWay4.JPG OneWay5.JPG OneWay6.JPG z

This will ask for group name, once entered, the resulting covariance and mean will be stored in a txt file with the name CovarianceGroupName.txt

